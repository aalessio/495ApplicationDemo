﻿//This script was written by Tony Alessio | Last edited by Tony Alessio | Modified on Jan 27, 2017

using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;

public class PlayerHealthUI : MonoBehaviour {

    /* This section is for the Unity Object handling of the UI elements: HP_Bar_Fill & HP_Bar_Text */
    [Tooltip("Drag and Drop the UI element for the player's HP bar (Usually an image)")]
    public Image p1_hp_bar;

    [Tooltip("Drag and Drop the UI element for the player's HP bar text (Usually a text field)")]
    public Text p1_hp_text;
	
	// Update is called once per frame
	void Update () {
        /* Converts the current HP into a ratio -> p1_hp_ratio:p1_start_health */
        float p1_hp_ratio = PlayerHealth.p1_health / PlayerHealth.p1_start_health;

        /* Changes the size of the bar to reflect the player's current HP */
        p1_hp_bar.rectTransform.localScale = new Vector3(p1_hp_ratio, 1, 1);

        /* Displays the current health of the player in a percentage value */
        p1_hp_text.text = "Player Health: " + (p1_hp_ratio * 100).ToString("0") + '%';

    }
}