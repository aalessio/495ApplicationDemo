//This script was written by Tony Alessio | Last edited by Tony Alessio | Modified on Jan 27, 2017

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerHealth : MonoBehaviour {

	//Variables
	[Tooltip("Health value for Player #1. Takes a value between 0 and 100.")]
	public static float p1_health = 0;		//Player One's health value

	[Tooltip("Starting health value for Player #1. Takes a value between 0 and 100.")]
	public static float p1_start_health = 100;		//Player One's health value

	// Use this for initialization
	void Start () {
		//Initializes the player's health (to p1_start_health) upon starting the game
		p1_health = p1_start_health;
	}
	
	// Update is called once per frame
	void Update () {

		/* This looks for (Spacebar) input in order to reduce player HP */
        if (Input.GetButton("Jump"))
        {
            if (!(p1_health <= 0) )     //Player's HP must not be equal to or less than zero
            {
                p1_health = p1_health - 1;
            }
        }

		/* This looks for (Mouse_Left_Button or Left Ctrl) input in order to increase player HP */
		if (Input.GetButton("Fire1"))
        {
            if (!(p1_health >= 100))     //Player's HP must not be equal to or greater than 100
            {
                p1_health = p1_health + 1;
            }
		}
    }
}
